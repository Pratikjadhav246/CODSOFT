// function blinker() {
//     $('.blink-me').fadeOut(200);
//     $('.blink-me').fadeIn(200);
// }
// setInterval(blinker, 500);

// Select elements
const buttons = document.querySelectorAll('.button');
const operationScreen = document.querySelector('.calc-operation');
const typedScreen = document.querySelector('.calc-typed');

// Variables to store current input and operation
let currentInput = '';
let currentOperation = '';

// Function to update the display
function updateDisplay() {
    typedScreen.innerHTML = currentInput + '<span class="blink-me">_</span>';
    operationScreen.textContent = currentOperation;
}

// Function to handle button clicks
function handleButtonClick(event) {
    const buttonText = event.target.textContent;

    if (buttonText >= '0' && buttonText <= '9' || buttonText === '.') {
        // Append number or dot to current input
        currentInput += buttonText;
    } else if (buttonText === 'C') {
        // Clear everything
        currentInput = '';
        currentOperation = '';
    } else if (buttonText === '<') {
        // Remove the last character from current input
        currentInput = currentInput.slice(0, -1);
    } else if (buttonText === '=') {
        // Calculate the result
        try {
            currentInput = eval(currentOperation + currentInput).toString();
            currentOperation = '';
        } catch (error) {
            currentInput = 'Error';
        }
    } else {
        // Append operator to current operation and reset current input
        currentOperation += currentInput + ' ' + buttonText + ' ';
        currentInput = '';
    }

    // Update the display
    updateDisplay();
}

// Add event listeners to buttons
buttons.forEach(button => {
    button.addEventListener('click', handleButtonClick);
});

// Blinking cursor function
function blinker() {
    const blinkMe = document.querySelector('.blink-me');
    blinkMe.style.visibility = (blinkMe.style.visibility === 'hidden' ? '' : 'hidden');
}
setInterval(blinker, 500);

// Initialize display
updateDisplay();
