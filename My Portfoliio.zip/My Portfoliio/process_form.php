<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Validate and sanitize input
    $name = htmlspecialchars(strip_tags(trim($name)));
    $email = filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    $subject = htmlspecialchars(strip_tags(trim($subject)));
    $message = htmlspecialchars(strip_tags(trim($message)));

    // Check if email is valid
    if ($email) {
        // Compose email message
        $to = "pratik46jadhav@gmail.com";
        $subject = "New Contact Form Submission - $subject";
        $messageBody = "Name: $name\nEmail: $email\nSubject: $subject\n\nMessage:\n$message";

        // Send email
        mail($to, $subject, $messageBody);

        // You can also redirect the user to a thank you page
        header("Location: thank-you.html");
        exit;
    } else {
        echo "Invalid email address. Please go back and try again.";
    }
} else {
    echo "Invalid request. Please submit the form from the contact page.";
}
?>
