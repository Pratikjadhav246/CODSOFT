

var typed = new Typed(".text", {
    strings: ["Web Developer", "Front-end Developer"],
    typeSpeed: 50,
    backSpeed: 50,
    backDelay: 800,
    loop: true
});


//For Menu bar
function toggleMenu() {
    var menuToggle = document.querySelector('.menu-toggle');
    var navbar = document.querySelector('.navbar');

    navbar.classList.toggle('show');


    if (navbar.classList.contains('show')) {
        menuToggle.innerHTML = "&#10005;";
        menuToggle.classList.add('x-icon');
    } else {
        menuToggle.innerHTML = "&#9776;";
        menuToggle.classList.remove('x-icon');
    }
}

function closeMenu() {
    var menuToggle = document.querySelector('.menu-toggle');
    var navbar = document.querySelector('.navbar');

    navbar.classList.remove('show');
    menuToggle.innerHTML = "&#9776;";
    menuToggle.classList.remove('x-icon');
}


//For Pop Up message on theme button




// Below Code is for theme Section



var h = document.querySelector(".theme");
var body = document.querySelector("body");
var lighttheme = document.querySelector(".about-img img");
var home = document.querySelector(".home");
var navbar = document.querySelector(".navbar")
var texts = document.querySelectorAll(".logo, .navbar a, .menu-toggle");
var header = document.querySelector(".header");
var texthomes = document.querySelectorAll(".home-content h3 , .home-content h1, .home-content p");
var spans = document.querySelectorAll(".home-content span, .about-text h2 span, .sub-title span, .main-text h2 span, .contact-text h2 span");
var profiles = document.querySelectorAll(".home-sci a, .contact-icons i");
var buttons = document.querySelectorAll(" .btn-box, .read , .contact-form form .send ");
var abouttexts = document.querySelectorAll(".about-text h2, .about-text h4, .about-text p");
var services = document.querySelectorAll(".sub-title, .radial-bars .percentage, .radial-bars .text , .services-list div h2, .services-list div p");
var serviceis = document.querySelectorAll(".services-list div i:nth-child(1), .services-list div i:nth-child(2), .services-list div i:nth-child(3)");
var skills = document.querySelectorAll(".heading1, .main-text h2, .contact-text h2, .contact-list li, .contact-text h4,.contact-text p, .technical-bars .bar .info span");
var percentags = document.querySelectorAll(".technical-bars .bar .progress-line span, .path");
var progresslines = document.querySelector(".progress-line span::after");
var contactlist = document.querySelectorAll(".contact-list i");
var forms = document.querySelectorAll(".contact-form form input:nth-child(1), .contact-form form input:nth-child(2), .contact-form form input:nth-child(3), .contact-form textarea");
var lasttext = document.querySelector(".last-text p");
var themecolors = document.querySelectorAll(".theme i, .top i ");
var hovers = document.querySelectorAll(" .btn-box, .read , .contact-form form .send ");
var footers  = document.querySelector("footer");
var footercont = document.querySelector(".footer-container");
var footerheader = document.querySelectorAll(".footer-section h3");
var footerula = document.querySelectorAll(".footer-section ul li a");
var footiconcolor = document.querySelectorAll(".footer-section ul li a i")


var theme = 0;

h.addEventListener("click", function (event) {

    event.preventDefault();


    if (theme == 0) {
        // h.innerHTML = "<i class='bx bxs-sun'></i>";
        body.style.background = "white";
        home.style.backgroundImage = "url('/images/themewhiteimage.jpg')";
        lighttheme.src = "/images/lighttheme.png";

        texts.forEach(function (text) {
            text.style.color = "black";
        });

        header.style.background = "#E9A881";
        navbar.style.background = "#E9A881";
        navbar.style.borderColor = "black";

        texthomes.forEach(function (texthome) {
            texthome.style.color = "black";
        });

        spans.forEach(function (span) {
            span.style.color = "#E9A881";
        });

        profiles.forEach(function (icons) {
            icons.style.color = "#000";
            icons.style.borderColor = "#E9A881";
        });

        buttons.forEach(function (button) {
            button.style.color = "black"
            button.style.backgroundColor = "#E9A881"
        });

        abouttexts.forEach(function (abouttext) {
            abouttext.style.color = "black"
        });

        services.forEach(function (service) {
            service.style.color = "black"
        });

        serviceis.forEach(function (servicei) {
            servicei.style.color = "#E9A982"
        });

        skills.forEach(function (skill) {
            skill.style.color = "#000000"
        });

        document.documentElement.style.setProperty('--progress-line-color', '#081b29');
        document.documentElement.style.setProperty('--progress-line-bg', '#fff');

        percentags.forEach(function (percentag) {
            percentag.style.background = "#E9A982"
            percentag.style.stroke = "#E9A982"
        });


        contactlist.forEach(function (contact) {
            contact.style.color = "#E9A881";

        });

        forms.forEach(function (form) {
            form.style.background = "#9ca3af";
            form.style.color = "#020617";
        });


        themecolors.forEach(function (themecolor) {
            themecolor.style.color = "black";
            themecolor.style.background = "#E9A881";
            themecolor.style.border = "1px solid #081b29"
        });

        hovers.forEach(function (hover) {
            hover.style.boxShadow = "0 0 5px #E9A881, 0 0 25px #E9A881 ";

        });


        // lasttext.style.background = "#E9A881"
        // lasttext.style.color = "#fff"

        footers.style.borderColor = "black";
        footers.style.background = "#E9A881";

        footerheader.forEach(function (footerh) {
            footerh.style.color = "black";
        });

        footerula.forEach(function (footera) {
            footera.style.color = "black";
        });

        footiconcolor.forEach(function (footcolor) {
            footcolor.style.color = "#fff";
        });

        


        theme = 1;
    } else {
        // h.innerHTML = "<i class='bx bx-sun'></i>";
        body.style.background = "#081b29";
        home.style.backgroundImage = "url('/images/Landing.jpg')";
        lighttheme.src = "/images/smallimage2.png";

        texts.forEach(function (text) {
            text.style.color = "white";
        });

        header.style.background = "#081b29";
        navbar.style.background = "#081b29";
        navbar.style.borderColor = "#0ef";

        texthomes.forEach(function (texthome) {
            texthome.style.color = "white";
        });

        spans.forEach(function (span) {
            span.style.color = "#0ef";
        });


        profiles.forEach(function (icons) {
            icons.style.color = "#0ef"
            icons.style.borderColor = "#0ef";
        });

        buttons.forEach(function (button) {
            button.style.color = "#081b29"
            button.style.backgroundColor = "#0ef"
        });

        abouttexts.forEach(function (abouttext) {
            abouttext.style.color = "white"
        });

        services.forEach(function (service) {
            service.style.color = "white"
        });

        serviceis.forEach(function (servicei) {
            servicei.style.color = "#00eeff"
        });

        skills.forEach(function (skill) {
            skill.style.color = "white"
        });

        document.documentElement.style.setProperty('--progress-line-color', '#fff');
        document.documentElement.style.setProperty('--progress-line-bg', '#081b29');

        percentags.forEach(function (percentag) {
            percentag.style.background = "#0ef"
            percentag.style.stroke = "#0ef"
        });

        contactlist.forEach(function (contact) {
            contact.style.color = "#0ef"
        });

        forms.forEach(function (form) {
            form.style.background = "#fff";
            form.style.color = "#000000";
        });

        // lasttext.style.background = "rgb(7, 85, 91)";
        // lasttext.style.color = "#000000"

        themecolors.forEach(function (themecolor) {
        themecolor.style.color = "#081b29";
        themecolor.style.background = "#0ef";
        themecolor.style.border = "none"
        });

        hovers.forEach(function (hover) {
            hover.style.boxShadow = "0 0 5px #0ef, 0 0 25px #0ef ";
        });

        footers.style.borderColor = "cyan";
        footers.style.background = "#081b29"

        footerheader.forEach(function (footerh) {
            footerh.style.color = "#fff";
        });

        footerula.forEach(function (footera) {
            footera.style.color = "#b0b0b0";
        });

        footiconcolor.forEach(function (footcolor) {
            footcolor.style.color = "#3498db";
        });

        
        theme = 0;
    }
});
